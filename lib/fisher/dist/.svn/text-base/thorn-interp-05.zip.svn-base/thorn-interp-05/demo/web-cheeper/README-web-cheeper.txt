This runs a simple Web interface to the Cheeper program.

Run it with: 
  ./run-web-cheeper

Then, point a web browser (on the same machine) to http://localhost:4121

You will get a web page, presenting some wisdom, ranked in order of popularity.  You can: 

* Vote for or against an existing piece of wisdom
* Delete an existing piece of wisdom.
* Proclaim some new wisdom (by typing it in the text field and pressing
  "Proclaim!")
* Filter the wisdom, getting only wisdom about (e.g.) "Math", by typing the 
  string "Math" in the text field and pressing "List!").

If you want to run this program over the internet, edit the file
web-cheeper-server, changing the seventh line:
  host = "localhost"; // Can be a hostname: "codu.org"; 
to refer to your own host, e.g., if you're putting it up at
cheeper.ibm.com, you'd use
  host = "cheeper.ibm.com"; // Can be a hostname: "codu.org"; 

Then, if all works properly and your firewalls cooperate, anyone on the net
can point a web browser at your machine: 
  http://cheeper.ibm.com:4121
and view and chirp to that Cheeper database.
