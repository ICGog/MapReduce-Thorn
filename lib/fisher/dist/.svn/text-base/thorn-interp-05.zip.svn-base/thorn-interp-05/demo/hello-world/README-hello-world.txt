Run by typing:

  th -f hello-world.th
