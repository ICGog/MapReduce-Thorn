Simple script to count number of occurrences of each distinct word in
a text file, specified as a command-line argument.  E.g.:

  th -f wordcount.th -- corpus.txt
