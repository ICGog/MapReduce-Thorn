Dice prints a bar graph giving a frequency distribution of some dice, suitable
for explaining these concepts to a 6-year-old.  

./run-dice prints a frequency graph of 100 rolls of 2 six-sided dice.

th -f dice.th -- 200 4 2     prints a frequency graph of 200 rolls 
of four 2-sided dice.
