This example shows up in many Thorn talks.  It is a simple component that
starts two components up. Those two volley a number back and forth,
decrementing it every time, until it reaches zero and one loses.

Run with ./run-thorn
