This is a demonstration of the Dining Philosophers problem in Thorn.  It is
the basis of one of the examples in the Thorn paper.

To run a version of the Dining Philosophers problem where you can see what's
going on: 

th -s phil-monitored.th 

The philosophers are Aristotle, Berkeley, Church, Descartes, and Emerson.

