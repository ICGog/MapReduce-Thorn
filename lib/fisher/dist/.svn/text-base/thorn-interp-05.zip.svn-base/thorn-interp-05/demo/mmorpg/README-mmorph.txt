This is the Minimalist Multiplayer On-Line Role-Playing Game.  It allows for a
(limited) amount of roleplay over a cheerful little game of pingpong.  The two
players type adverbs (or, in advanced play, entire adverbial clauses)
describing how they hit the ball to each other.  A blank input loses; anything
else continues play.

Run ./run-ping in one shell, and ./run-pong in another.

Here's a transcript: 

---- one window ----
/thorn/fisherws/fisher/demo/mmorpg: ./run-ping
Hit how?tiredly
Pong returns the ball eagerly.
Hit how?accidentally
Pong returns the ball by hitting it with a bottle of off-brand pineapple soda.
Hit how?
You lose!

---- the other window ----
~/thorn/fisherws/fisher/demo/mmorpg: ./run-pong
Ping serves the ball tiredly.
Hit how?eagerly
Ping returns the ball accidentally.
Hit how?by hitting it with a bottle of off-brand pineapple soda 
You win!
