This runs a bottom-of-the-line HTTP server.

Run this demo with ./run-server

Then, point a web browser on the same machine to http://localhost:4321

You'll get a message that the server doesn't do directories.

So, give it a path to a file that you have access to on your computer.  On
mine, I use 
  http://localhost:4321/Users/bard/.emacs

and poof, my .emacs file shows up in the web browser.

After you are done, kill the server with control-c in the shell window.  It is
a horribly unsafe server, and will reveal any file you have read access to.
